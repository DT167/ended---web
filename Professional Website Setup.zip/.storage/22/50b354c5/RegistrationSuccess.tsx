import Navigation from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Calendar, Clock, Video, User, Copy } from 'lucide-react';
import { Class, Registration } from '@/lib/storage';
import { toast } from 'sonner';

interface RegistrationSuccessProps {
  class: Class;
  registration: Registration;
  onReset: () => void;
}

export default function RegistrationSuccess({ class: cls, registration, onReset }: RegistrationSuccessProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('he-IL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const copyZoomLink = () => {
    navigator.clipboard.writeText(cls.zoomLink);
    toast.success('קישור הזום הועתק ללוח');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <Navigation />
      
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">רישום הושלם בהצלחה!</h1>
          <p className="text-xl text-gray-600">תודה שנרשמתם לשיעור שלנו</p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
              <User className="h-5 w-5" />
              <span>פרטי הרישום</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <span className="font-medium text-gray-700">שם: </span>
              <span className="text-gray-900">{registration.fullName}</span>
            </div>
            <div>
              <span className="font-medium text-gray-700">מספר רישום: </span>
              <span className="text-gray-900">#{registration.id}</span>
            </div>
            <div>
              <span className="font-medium text-gray-700">תאריך רישום: </span>
              <span className="text-gray-900">
                {new Date(registration.registeredAt).toLocaleDateString('he-IL')}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{cls.title}</span>
              <Badge variant="default">נרשמתם בהצלחה</Badge>
            </CardTitle>
            <CardDescription>פרטי השיעור שנרשמתם אליו</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Calendar className="h-4 w-4 text-blue-600" />
              <span className="font-medium">תאריך:</span>
              <span>{formatDate(cls.date)}</span>
            </div>
            
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Clock className="h-4 w-4 text-blue-600" />
              <span className="font-medium">שעה:</span>
              <span>{cls.time}</span>
            </div>
            
            {cls.zoomLink && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 rtl:space-x-reverse mb-2">
                  <Video className="h-4 w-4 text-blue-600" />
                  <span className="font-medium text-blue-900">קישור לשיעור:</span>
                </div>
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <a 
                    href={cls.zoomLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 underline flex-1 break-all"
                  >
                    {cls.zoomLink}
                  </a>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyZoomLink}
                    className="flex items-center space-x-1 rtl:space-x-reverse"
                  >
                    <Copy className="h-4 w-4" />
                    <span>העתק</span>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex space-x-4 rtl:space-x-reverse">
          <Button onClick={onReset} className="flex-1">
            רישום לשיעור נוסף
          </Button>
          <Button variant="outline" asChild className="flex-1">
            <a href="/">חזרה לדף הבית</a>
          </Button>
        </div>
      </div>
    </div>
  );
}