# MVP Todo List for Organization T Website

## Core Features Implementation:
1. **Home Page** (`src/pages/Index.tsx`) - Overview of the site with navigation
2. **Classes Info Page** (`src/pages/ClassesInfo.tsx`) - Display available classes
3. **Registration Page** (`src/pages/Registration.tsx`) - User registration form
4. **Admin Page** (`src/pages/Admin.tsx`) - Admin panel to manage classes
5. **Organization Page** (`src/pages/Organization.tsx`) - About organization T
6. **Registration Success** (`src/components/RegistrationSuccess.tsx`) - Show Zoom link after registration

## Data Management:
- **Local Storage** for MVP (classes, registrations, admin auth)
- Simple admin password: "admin123" (hardcoded for MVP)

## File Structure:
1. `src/App.tsx` - Add routing for all pages
2. `src/pages/Index.tsx` - Home page with navigation
3. `src/pages/ClassesInfo.tsx` - Display classes with status
4. `src/pages/Registration.tsx` - Registration form
5. `src/pages/Admin.tsx` - Admin dashboard
6. `src/pages/Organization.tsx` - Organization info page
7. `src/components/RegistrationSuccess.tsx` - Success component
8. `src/lib/storage.ts` - Local storage utilities

## Key Features:
- Responsive design with Hebrew support
- Professional UI with Shadcn components
- Admin can add classes (title, date, time, zoom link)
- Users register with full name only
- Past classes automatically disabled
- Registration shows Zoom link