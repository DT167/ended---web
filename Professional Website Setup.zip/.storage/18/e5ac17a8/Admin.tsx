import Navigation from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { storage, Class } from '@/lib/storage';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Lock, Plus, Calendar, Clock, Video, Users, Trash2 } from 'lucide-react';

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [classes, setClasses] = useState<Class[]>([]);
  const [newClass, setNewClass] = useState({
    title: '',
    date: '',
    time: '',
    zoomLink: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      setClasses(storage.getClasses());
    }
  }, [isAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (storage.validateAdminPassword(password)) {
      setIsAuthenticated(true);
      toast.success('התחברות בוצעה בהצלחה');
    } else {
      toast.error('סיסמה שגויה');
    }
  };

  const handleAddClass = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newClass.title.trim() || !newClass.date || !newClass.time) {
      toast.error('אנא מלאו את כל השדות הנדרשים');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const addedClass = storage.addClass({
        title: newClass.title.trim(),
        date: newClass.date,
        time: newClass.time,
        zoomLink: newClass.zoomLink.trim(),
      });
      
      setClasses(storage.getClasses());
      setNewClass({ title: '', date: '', time: '', zoomLink: '' });
      toast.success('השיעור נוסף בהצלחה');
    } catch (error) {
      toast.error('אירעה שגיאה בהוספת השיעור');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteClass = (classId: string) => {
    const updatedClasses = classes.filter(cls => cls.id !== classId);
    storage.saveClasses(updatedClasses);
    setClasses(updatedClasses);
    toast.success('השיעור נמחק בהצלחה');
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('he-IL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const logout = () => {
    setIsAuthenticated(false);
    setPassword('');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        <Navigation />
        
        <div className="max-w-md mx-auto px-4 py-12">
          <Card>
            <CardHeader className="text-center">
              <Lock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <CardTitle>כניסת מנהל</CardTitle>
              <CardDescription>
                אנא הזינו את סיסמת המנהל להמשך
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="password">סיסמה</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="הזינו סיסמה"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full">
                  התחבר
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">פאנל מנהל</h1>
            <p className="text-xl text-gray-600">ניהול שיעורים ורישומים</p>
          </div>
          <Button variant="outline" onClick={logout}>
            התנתק
          </Button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Add New Class Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
                <Plus className="h-5 w-5" />
                <span>הוספת שיעור חדש</span>
              </CardTitle>
              <CardDescription>
                מלאו את הפרטים להוספת שיעור חדש למערכת
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddClass} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">כותרת השיעור *</Label>
                  <Input
                    id="title"
                    type="text"
                    placeholder="הזינו את כותרת השיעור"
                    value={newClass.title}
                    onChange={(e) => setNewClass({ ...newClass, title: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date">תאריך *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newClass.date}
                    onChange={(e) => setNewClass({ ...newClass, date: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time">שעה *</Label>
                  <Input
                    id="time"
                    type="time"
                    value={newClass.time}
                    onChange={(e) => setNewClass({ ...newClass, time: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="zoomLink">קישור זום</Label>
                  <Textarea
                    id="zoomLink"
                    placeholder="הזינו את קישור הזום לשיעור"
                    value={newClass.zoomLink}
                    onChange={(e) => setNewClass({ ...newClass, zoomLink: e.target.value })}
                    rows={3}
                  />
                </div>

                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? 'מוסיף שיעור...' : 'הוסף שיעור'}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Classes Overview */}
          <Card>
            <CardHeader>
              <CardTitle>סקירת שיעורים</CardTitle>
              <CardDescription>
                כל השיעורים במערכת ({classes.length} שיעורים)
              </CardDescription>
            </CardHeader>
            <CardContent>
              {classes.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>אין שיעורים במערכת</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {classes.map((cls) => {
                    const registrations = storage.getRegistrationsForClass(cls.id);
                    const isPast = storage.isClassPast(cls.date, cls.time);
                    
                    return (
                      <div key={cls.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold text-lg">{cls.title}</h3>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteClass(cls.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        
                        <div className="space-y-1 text-sm text-gray-600">
                          <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            <Calendar className="h-4 w-4" />
                            <span>{formatDate(cls.date)} בשעה {cls.time}</span>
                            {isPast && <span className="text-red-500">(הסתיים)</span>}
                          </div>
                          
                          <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            <Users className="h-4 w-4" />
                            <span>{registrations.length} נרשמים</span>
                          </div>
                          
                          {cls.zoomLink && (
                            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                              <Video className="h-4 w-4" />
                              <span>יש קישור זום</span>
                            </div>
                          )}
                        </div>
                        
                        {registrations.length > 0 && (
                          <div className="mt-3 pt-3 border-t">
                            <p className="text-sm font-medium mb-2">רשימת נרשמים:</p>
                            <div className="space-y-1">
                              {registrations.map((reg) => (
                                <div key={reg.id} className="text-sm text-gray-600">
                                  {reg.fullName}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}