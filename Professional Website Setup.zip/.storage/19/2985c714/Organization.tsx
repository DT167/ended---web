import Navigation from '@/components/Navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Building, Heart, Star, Users } from 'lucide-react';

export default function Organization() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-16">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full blur-3xl opacity-20 w-64 h-64 mx-auto"></div>
            <Building className="h-24 w-24 text-purple-600 mx-auto mb-6 relative z-10" />
          </div>
          <h1 className="text-6xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-6">
            ארגון T
          </h1>
          <p className="text-2xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            ארגון מוביל בתחום החינוך והפיתוח האישי, המחויב להעצמת אנשים באמצעות למידה איכותית וחדשנית
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br from-white to-purple-50">
            <CardContent className="p-8 text-center">
              <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:bg-purple-200 transition-colors">
                <Heart className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">המשימה שלנו</h3>
              <p className="text-gray-600 leading-relaxed">
                להעניק חוויות למידה מעשירות ומשמעותיות שמעצימות את הפוטנציאל האנושי ומובילות לצמיחה אישית ומקצועית
              </p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br from-white to-blue-50">
            <CardContent className="p-8 text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:bg-blue-200 transition-colors">
                <Star className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">החזון שלנו</h3>
              <p className="text-gray-600 leading-relaxed">
                להיות הארגון המוביל בישראל בתחום החינוך החדשני, ולהשפיע חיובית על חיי אלפי אנשים באמצעות תוכניות איכות
              </p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br from-white to-indigo-50 md:col-span-2 lg:col-span-1">
            <CardContent className="p-8 text-center">
              <div className="bg-indigo-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:bg-indigo-200 transition-colors">
                <Users className="h-8 w-8 text-indigo-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">הקהילה שלנו</h3>
              <p className="text-gray-600 leading-relaxed">
                קהילה תוססת של לומדים, מורים ומובילי דעה שחולקים ידע, חוויות והשראה במטרה ליצור שינוי חיובי
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-12 mb-16">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-gray-900 mb-8">הסיפור שלנו</h2>
            <div className="space-y-6 text-lg text-gray-700 leading-relaxed">
              <p>
                ארגון T נוסד מתוך אמונה עמוקה בכוחה של הלמידה לשנות חיים. אנחנו מאמינים שכל אדם ראוי לגישה לחינוך איכותי 
                ולהזדמנויות פיתוח שיאפשרו לו לממש את הפוטנציאל שלו במלואו.
              </p>
              <p>
                במהלך השנים פיתחנו מתודולוגיות חדשניות ותוכניות מותאמות אישית שמתמקדות בצרכים הייחודיים של כל משתתף. 
                הגישה שלנו משלבת למידה תיאורטית עם יישום מעשי, ויוצרת חוויה מעשירה ובלתי נשכחת.
              </p>
              <p>
                היום, אנחנו גאים להיות חלק מהמסע האישי והמקצועי של מאות אנשים, ולראות איך השיעורים שלנו משפיעים 
                לטובה על החיים שלהם ועל הקהילות שהם חלק מהן.
              </p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-3xl p-12 text-white">
            <h2 className="text-3xl font-bold mb-6">הצטרפו אלינו למסע</h2>
            <p className="text-xl mb-8 opacity-90">
              גלו את הפוטנציאל שלכם והצטרפו לקהילה שלנו של לומדים ומתפתחים
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-sm">
              <div className="bg-white/20 rounded-full px-6 py-3">
                <span className="font-semibold">למידה חדשנית</span>
              </div>
              <div className="bg-white/20 rounded-full px-6 py-3">
                <span className="font-semibold">קהילה תומכת</span>
              </div>
              <div className="bg-white/20 rounded-full px-6 py-3">
                <span className="font-semibold">התפתחות אישית</span>
              </div>
              <div className="bg-white/20 rounded-full px-6 py-3">
                <span className="font-semibold">הצלחה מקצועית</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}