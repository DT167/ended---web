import Navigation from '@/components/Navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Users, Video } from 'lucide-react';
import { storage, Class } from '@/lib/storage';
import { useEffect, useState } from 'react';

export default function ClassesInfo() {
  const [classes, setClasses] = useState<Class[]>([]);

  useEffect(() => {
    setClasses(storage.getClasses());
  }, []);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('he-IL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatTime = (timeString: string) => {
    return timeString;
  };

  const getClassStatus = (cls: Class) => {
    const isPast = storage.isClassPast(cls.date, cls.time);
    const registrations = storage.getRegistrationsForClass(cls.id);
    
    if (isPast) {
      return { label: 'הסתיים', variant: 'secondary' as const };
    }
    
    return { label: 'זמין לרישום', variant: 'default' as const };
  };

  if (classes.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-8">מידע על השיעורים</h1>
            <div className="bg-white rounded-lg shadow-lg p-12">
              <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h2 className="text-2xl font-semibold text-gray-600 mb-2">אין שיעורים זמינים כרגע</h2>
              <p className="text-gray-500">השיעורים החדשים יתווספו בקרוב. אנא בדקו שוב מאוחר יותר.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">מידע על השיעורים</h1>
          <p className="text-xl text-gray-600">כל השיעורים הזמינים במערכת</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {classes.map((cls) => {
            const status = getClassStatus(cls);
            const registrations = storage.getRegistrationsForClass(cls.id);
            
            return (
              <Card key={cls.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-xl">{cls.title}</CardTitle>
                    <Badge variant={status.variant}>{status.label}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                    <Calendar className="h-4 w-4" />
                    <span>{formatDate(cls.date)}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                    <Clock className="h-4 w-4" />
                    <span>{formatTime(cls.time)}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                    <Users className="h-4 w-4" />
                    <span>{registrations.length} נרשמים</span>
                  </div>
                  
                  {cls.zoomLink && (
                    <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                      <Video className="h-4 w-4" />
                      <span>קישור זום זמין</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}