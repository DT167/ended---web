import Navigation from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { BookOpen, UserPlus, Building, Calendar } from 'lucide-react';

export default function Index() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            ברוכים הבאים לארגון T
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            פלטפורמה מתקדמת לרישום ומעקב אחר השיעורים שלנו. הצטרפו אלינו למסע למידה מרתק!
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <BookOpen className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <CardTitle>מידע על השיעורים</CardTitle>
              <CardDescription>
                צפו בכל השיעורים הזמינים ופרטיהם
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full">
                <Link to="/classes">צפייה בשיעורים</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <UserPlus className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <CardTitle>רישום לשיעורים</CardTitle>
              <CardDescription>
                הירשמו בקלות לשיעורים שמעניינים אתכם
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full">
                <Link to="/register">רישום עכשיו</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Building className="h-12 w-12 text-purple-600 mx-auto mb-4" />
              <CardTitle>אודות הארגון</CardTitle>
              <CardDescription>
                למדו עוד על הארגון שלנו ומטרותיו
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full">
                <Link to="/organization">קראו עלינו</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Calendar className="h-12 w-12 text-orange-600 mx-auto mb-4" />
              <CardTitle>מנהל השיעורים</CardTitle>
              <CardDescription>
                כניסה למנהלים להוספת שיעורים חדשים
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full">
                <Link to="/admin">כניסת מנהל</Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">למה לבחור בנו?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-semibold text-blue-600 mb-2">קל לשימוש</h3>
              <p className="text-gray-600">ממשק פשוט ונוח לרישום מהיר לשיעורים</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-green-600 mb-2">זמין תמיד</h3>
              <p className="text-gray-600">רישום 24/7 מכל מקום ובכל זמן</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-purple-600 mb-2">מעודכן</h3>
              <p className="text-gray-600">מידע עדכני על כל השיעורים והזמינות</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}