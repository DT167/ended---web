export interface Class {
  id: string;
  title: string;
  date: string;
  time: string;
  zoomLink: string;
  createdAt: string;
}

export interface Registration {
  id: string;
  classId: string;
  fullName: string;
  registeredAt: string;
}

const CLASSES_KEY = 'organization_t_classes';
const REGISTRATIONS_KEY = 'organization_t_registrations';
const ADMIN_PASSWORD = '025429';

export const storage = {
  // Classes management
  getClasses: (): Class[] => {
    const classes = localStorage.getItem(CLASSES_KEY);
    return classes ? JSON.parse(classes) : [];
  },

  saveClasses: (classes: Class[]): void => {
    localStorage.setItem(CLASSES_KEY, JSON.stringify(classes));
  },

  addClass: (classData: Omit<Class, 'id' | 'createdAt'>): Class => {
    const classes = storage.getClasses();
    const newClass: Class = {
      ...classData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    classes.push(newClass);
    storage.saveClasses(classes);
    return newClass;
  },

  // Registrations management
  getRegistrations: (): Registration[] => {
    const registrations = localStorage.getItem(REGISTRATIONS_KEY);
    return registrations ? JSON.parse(registrations) : [];
  },

  saveRegistrations: (registrations: Registration[]): void => {
    localStorage.setItem(REGISTRATIONS_KEY, JSON.stringify(registrations));
  },

  addRegistration: (classId: string, fullName: string): Registration => {
    const registrations = storage.getRegistrations();
    const newRegistration: Registration = {
      id: Date.now().toString(),
      classId,
      fullName,
      registeredAt: new Date().toISOString(),
    };
    registrations.push(newRegistration);
    storage.saveRegistrations(registrations);
    return newRegistration;
  },

  getRegistrationsForClass: (classId: string): Registration[] => {
    return storage.getRegistrations().filter(reg => reg.classId === classId);
  },

  // Utility functions
  isClassPast: (date: string, time: string): boolean => {
    const classDateTime = new Date(`${date}T${time}`);
    return classDateTime < new Date();
  },

  getAvailableClasses: (): Class[] => {
    return storage.getClasses().filter(cls => !storage.isClassPast(cls.date, cls.time));
  },

  // Admin authentication
  validateAdminPassword: (password: string): boolean => {
    return password === ADMIN_PASSWORD;
  },
};