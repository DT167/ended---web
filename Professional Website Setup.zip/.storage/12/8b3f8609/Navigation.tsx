import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home, BookOpen, UserPlus, Settings, Building } from 'lucide-react';

export default function Navigation() {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'דף הבית', icon: Home },
    { path: '/classes', label: 'מידע על השיעורים', icon: BookOpen },
    { path: '/register', label: 'רישום לשיעורים', icon: UserPlus },
    { path: '/organization', label: 'אודות הארגון', icon: Building },
    { path: '/admin', label: 'מנהל', icon: Settings },
  ];

  return (
    <nav className="bg-white shadow-lg border-b">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <h1 className="text-2xl font-bold text-blue-600">ארגון T</h1>
          </div>
          <div className="flex space-x-2 rtl:space-x-reverse">
            {navItems.map(({ path, label, icon: Icon }) => (
              <Button
                key={path}
                asChild
                variant={location.pathname === path ? 'default' : 'ghost'}
                size="sm"
              >
                <Link to={path} className="flex items-center space-x-2 rtl:space-x-reverse">
                  <Icon className="h-4 w-4" />
                  <span>{label}</span>
                </Link>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}