import Navigation from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { storage, Class } from '@/lib/storage';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import RegistrationSuccess from '@/components/RegistrationSuccess';
import { Calendar, Clock, Users } from 'lucide-react';

export default function Registration() {
  const [availableClasses, setAvailableClasses] = useState<Class[]>([]);
  const [fullName, setFullName] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationSuccess, setRegistrationSuccess] = useState<{
    class: Class;
    registration: any;
  } | null>(null);

  useEffect(() => {
    setAvailableClasses(storage.getAvailableClasses());
  }, []);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('he-IL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!fullName.trim()) {
      toast.error('אנא הזינו את השם המלא');
      return;
    }
    
    if (!selectedClassId) {
      toast.error('אנא בחרו שיעור');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const registration = storage.addRegistration(selectedClassId, fullName.trim());
      const selectedClass = availableClasses.find(cls => cls.id === selectedClassId);
      
      if (selectedClass) {
        setRegistrationSuccess({
          class: selectedClass,
          registration,
        });
        toast.success('הרישום הושלם בהצלחה!');
      }
    } catch (error) {
      toast.error('אירעה שגיאה ברישום. אנא נסו שוב.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setRegistrationSuccess(null);
    setFullName('');
    setSelectedClassId('');
    setAvailableClasses(storage.getAvailableClasses());
  };

  if (registrationSuccess) {
    return <RegistrationSuccess {...registrationSuccess} onReset={resetForm} />;
  }

  if (availableClasses.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-8">רישום לשיעורים</h1>
            <Card>
              <CardContent className="p-12 text-center">
                <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h2 className="text-2xl font-semibold text-gray-600 mb-2">אין שיעורים זמינים לרישום</h2>
                <p className="text-gray-500">כל השיעורים הנוכחיים הסתיימו או מלאים. אנא בדקו שוב מאוחר יותר.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">רישום לשיעורים</h1>
          <p className="text-xl text-gray-600">מלאו את הפרטים להשלמת הרישום</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>טופס רישום</CardTitle>
            <CardDescription>
              אנא מלאו את השם המלא ובחרו את השיעור הרצוי
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="fullName">שם מלא *</Label>
                <Input
                  id="fullName"
                  type="text"
                  placeholder="הזינו את השם המלא שלכם"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="class">בחירת שיעור *</Label>
                <Select value={selectedClassId} onValueChange={setSelectedClassId}>
                  <SelectTrigger>
                    <SelectValue placeholder="בחרו שיעור" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableClasses.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id}>
                        <div className="flex flex-col items-start">
                          <span className="font-medium">{cls.title}</span>
                          <span className="text-sm text-gray-500">
                            {formatDate(cls.date)} בשעה {cls.time}
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? 'מבצע רישום...' : 'השלמת רישום'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {selectedClassId && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>פרטי השיעור הנבחר</CardTitle>
            </CardHeader>
            <CardContent>
              {(() => {
                const selectedClass = availableClasses.find(cls => cls.id === selectedClassId);
                if (!selectedClass) return null;
                
                const registrations = storage.getRegistrationsForClass(selectedClass.id);
                
                return (
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold">{selectedClass.title}</h3>
                    
                    <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                      <Calendar className="h-4 w-4" />
                      <span>{formatDate(selectedClass.date)}</span>
                    </div>
                    
                    <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                      <Clock className="h-4 w-4" />
                      <span>{selectedClass.time}</span>
                    </div>
                    
                    <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
                      <Users className="h-4 w-4" />
                      <span>{registrations.length} נרשמים</span>
                    </div>
                  </div>
                );
              })()}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}